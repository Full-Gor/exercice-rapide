# ========================================
# KATAS SUPPLÉMENTAIRES POUR RÉVISER
# ========================================

puts "=== KATAS SUPPLÉMENTAIRES RUBY ==="

# ========================================
# KATA 1: GESTION D'UN BLOG
# ========================================
puts "\n--- Kata 1: Blog Simple ---"

class BlogPost
  attr_accessor :title, :content, :author, :published
  
  def initialize(title, content, author)
    @title = title
    @content = content
    @author = author
    @published = false
  end
  
  def publish!
    @published = true
    puts "Article '#{@title}' publié !"
  end
  
  def word_count
    @content.split.length
  end
end

# Créer des articles
post1 = BlogPost.new("Ruby Basics", "Ruby est un langage puissant", "Alice")
post2 = BlogPost.new("Rails Guide", "Rails facilite le développement web", "Bob")

# Publier et afficher
post1.publish!
puts "Mots dans l'article: #{post1.word_count}"

# ========================================
# KATA 2: CALCULATRICE AVANCÉE
# ========================================
puts "\n--- Kata 2: Calculatrice ---"

class Calculator
  def self.add(a, b)
    a + b
  end
  
  def self.multiply(a, b)
    a * b
  end
  
  def self.divide(a, b)
    return "Division par zéro !" if b == 0
    a.to_f / b
  end
end

puts "Addition: #{Calculator.add(5, 3)}"
puts "Multiplication: #{Calculator.multiply(4, 7)}"
puts "Division: #{Calculator.divide(10, 2)}"
puts "Division par zéro: #{Calculator.divide(10, 0)}"

# ========================================
# KATA 3: GESTION DE STOCK
# ========================================
puts "\n--- Kata 3: Stock ---"

class Product
  attr_accessor :name, :price, :quantity
  
  def initialize(name, price, quantity = 0)
    @name = name
    @price = price
    @quantity = quantity
  end
  
  def total_value
    @price * @quantity
  end
  
  def in_stock?
    @quantity > 0
  end
end

# Créer des produits
products = [
  Product.new("Laptop", 999.99, 5),
  Product.new("Souris", 25.50, 20),
  Product.new("Clavier", 75.00, 0)
]

# Afficher le stock
products.each do |product|
  status = product.in_stock? ? "En stock" : "Rupture"
  puts "#{product.name}: #{product.quantity} (#{status})"
end

# ========================================
# KATA 4: FILTRAGE ET TRANSFORMATION
# ========================================
puts "\n--- Kata 4: Filtrage ---"

numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Nombres pairs
evens = numbers.select { |n| n.even? }
puts "Pairs: #{evens}"

# Carrés des nombres impairs
odd_squares = numbers.select { |n| n.odd? }.map { |n| n * n }
puts "Carrés des impairs: #{odd_squares}"

# ========================================
# KATA 5: GESTION D'ÉTUDIANTS
# ========================================
puts "\n--- Kata 5: Étudiants ---"

class Student
  attr_accessor :name, :grades
  
  def initialize(name)
    @name = name
    @grades = []
  end
  
  def add_grade(grade)
    @grades << grade
  end
  
  def average_grade
    return 0 if @grades.empty?
    @grades.sum.to_f / @grades.length
  end
  
  def passed?
    average_grade >= 10
  end
end

# Créer des étudiants
student1 = Student.new("Alice")
student1.add_grade(15)
student1.add_grade(12)
student1.add_grade(18)

student2 = Student.new("Bob")
student2.add_grade(8)
student2.add_grade(9)
student2.add_grade(7)

# Afficher les résultats
[student1, student2].each do |student|
  status = student.passed? ? "Réussi" : "Échec"
  puts "#{student.name}: #{student.average_grade.round(2)} (#{status})"
end

# ========================================
# KATA 6: MANIPULATION DE TEXTE
# ========================================
puts "\n--- Kata 6: Texte ---"

def count_words(text)
  text.split.length
end

def reverse_words(text)
  text.split.reverse.join(" ")
end

def capitalize_sentences(text)
  text.split(". ").map(&:capitalize).join(". ")
end

text = "hello world. this is a test. ruby is great."
puts "Mots: #{count_words(text)}"
puts "Inversé: #{reverse_words(text)}"
puts "Capitalisé: #{capitalize_sentences(text)}"

# ========================================
# KATA 7: GESTION D'ÉVÉNEMENTS
# ========================================
puts "\n--- Kata 7: Événements ---"

class Event
  attr_accessor :name, :date, :attendees
  
  def initialize(name, date)
    @name = name
    @date = date
    @attendees = []
  end
  
  def add_attendee(name)
    @attendees << name
  end
  
  def full?
    @attendees.length >= 10
  end
  
  def info
    "Événement: #{@name} le #{@date} (#{@attendees.length} participants)"
  end
end

event = Event.new("Conférence Ruby", "2024-01-15")
event.add_attendee("Alice")
event.add_attendee("Bob")
event.add_attendee("Charlie")

puts event.info
puts "Complet: #{event.full?}"

# ========================================
# KATA 8: CALCULS MATHÉMATIQUES
# ========================================
puts "\n--- Kata 8: Math ---"

def fibonacci(n)
  return n if n <= 1
  fibonacci(n - 1) + fibonacci(n - 2)
end

def factorial(n)
  return 1 if n <= 1
  n * factorial(n - 1)
end

def prime?(n)
  return false if n < 2
  (2..Math.sqrt(n)).none? { |i| n % i == 0 }
end

puts "Fibonacci(5): #{fibonacci(5)}"
puts "Factorielle(5): #{factorial(5)}"
puts "7 est premier: #{prime?(7)}"
puts "8 est premier: #{prime?(8)}"

# ========================================
# KATA 9: GESTION DE FICHIERS
# ========================================
puts "\n--- Kata 9: Fichiers ---"

def create_file(filename, content)
  File.write(filename, content)
  puts "Fichier '#{filename}' créé"
end

def read_file(filename)
  return "Fichier inexistant" unless File.exist?(filename)
  File.read(filename)
end

# Créer un fichier
create_file("test.txt", "Contenu de test\nLigne 2\nLigne 3")

# Lire le fichier
content = read_file("test.txt")
puts "Contenu: #{content}"

# ========================================
# KATA 10: GESTION D'ERREURS
# ========================================
puts "\n--- Kata 10: Gestion d'erreurs ---"

def safe_divide(a, b)
  begin
    a / b
  rescue ZeroDivisionError
    "Erreur: Division par zéro"
  rescue => e
    "Erreur: #{e.message}"
  end
end

def validate_email(email)
  raise "Email vide" if email.nil? || email.empty?
  raise "Email invalide" unless email.include?("@")
  "Email valide: #{email}"
end

puts "Division sûre: #{safe_divide(10, 2)}"
puts "Division par zéro: #{safe_divide(10, 0)}"

begin
  puts validate_email("test@example.com")
  puts validate_email("")
rescue => e
  puts "Erreur capturée: #{e.message}"
end

puts "\n=== FIN KATAS SUPPLÉMENTAIRES ==="

